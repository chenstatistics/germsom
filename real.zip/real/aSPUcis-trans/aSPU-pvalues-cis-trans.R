## aSPU p values: cis/trans comparison 

library(data.table)
library(varhandle)

setwd("D:/Work/Wei/Data/Association/2019-5-8aSPUpvalues")

pval <- read.csv("2019-5-12-germline-somaticDriver-association-pvalue.csv")
rownames(pval) <- pval$X
pval <- pval[,-1]

m = dim(pval)[1]
n = dim(pval)[2]

cnames <- colnames(pval)

p1 <- c()
p2 <- c()
j = 0

transg = 0
transs = 0
for (i in seq(2, dim(pval)[2], 2)){
  k <- which(pval[,i-1] %in% cnames[i])

  if (length(k) > 0){
    j = j+1
    p1[j] <- pval[k,i]
    # p2[j] <- (sum(pval[,i])-pval[k,i])/(dim(pval)[1]-1)
  }
}

cisg = sum(p1 > 0.05)
ciss = length(p1)-cisg

transg = sum(pval[,seq(2, dim(pval)[2], 2)] > 0.05)-cisg
transs = m*n/2-length(p1)-transg

### create 2 by 2 table
table22 <- matrix(c(ciss,transs,cisg,transg),ncol = 2)

### perform fisher exact test 
model <- fisher.test(table22)
pvalue <- model$p.value
pvalue
# [1] 0.3393348

pval1 <- read.csv("2019-5-12-germline-somaticDriver-association-pvalue_order.csv")
rownames(pval1) <- pval1$X
pval1 <- pval1[,-1]

sum(pval1<0.05)
# [1] 1728
sum(pval1>=0.05)
# [1] 21672

