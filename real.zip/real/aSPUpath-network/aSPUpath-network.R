## aSPUpath network

library(data.table)
library(varhandle)
library(gplots)
library(reshape2)

setwd("D:/Work/Wei/Data/Association/2019-5-11aSPUpathPvalues")

########### read p values from aSPU assciation test results 2019-5-11 (combined 2019-5-13) #############
pval <- read.csv("2019-5-13-aSPUpath-germline-somaticDriver-association-pvalue_order.csv")
rownames(pval) <- pval$X
pval <- pval[,-1]        ## each row is somatic mutation gene, each column is pathway (156 by 10)  

colnames(pval)[9] <- "TP53pathway"

pval_mtx <- as.matrix(pval)
pval_mtx1 <- -log10(pval_mtx + 10^-6)

# ##
# pval_mtx1_melt <- melt(pval_mtx1)
# colnames(pval_mtx1_melt) <- c("somatic","target","neglog10pvalue")
# 
# pval_mtx1_melt$attribute <- "target"
# 
# pval_mtx1_melt$attribute0 <- pval_mtx1_melt$neglog10pvalue
# 
# write.csv(pval_mtx1_melt, file = "2019-5-24-aSPUpath-germline-somaticDriver-association-neglog10pvalue_order_melt.csv")



### 
## select genes 
gene_freq001 <- read.csv("2019-5-7-driver-gene-freq001.csv")
gene_freq001 <- gene_freq001[,-1]
gene_freq001 <- unfactor(gene_freq001)  ## 59 genes


pval_freq001 <- pval[which(rownames(pval) %in% gene_freq001),]  
pval_freq001_mtx <- as.matrix(pval_freq001)
pval_freq001_mtx1 <- -log10(pval_freq001_mtx + 10^-6)


pval_freq001_mtx1_melt <- melt(pval_freq001_mtx1)
colnames(pval_freq001_mtx1_melt) <- c("somatic","target","neglog10pvalue")

pval_freq001_mtx1_melt$attribute <- "target"

att0 <- c()
for (i in 1:dim(pval_freq001_mtx1)[1]){
  att0[i] = sum(pval_freq001_mtx1[i,] > -log10(0.05 + 10^-6))
}

# pval_freq001_mtx1_melt$attribute0 <- pval_freq001_mtx1_melt$neglog10pvalue
pval_freq001_mtx1_melt$attribute0 <- rep(att0,dim(pval_freq001_mtx1)[2])

att1 <- c()
for (i in 1:dim(pval_freq001_mtx1)[2]){
  att1[i] = sum(pval_freq001_mtx1[,i] > -log10(0.05 + 10^-6))
}

pval_freq001_mtx1_melt$attribute1 <- rep(att1,each=dim(pval_freq001_mtx1)[1])

write.csv(pval_freq001_mtx1_melt, file = "2019-5-24-aSPUpath-germline-somaticDriver-association-neglog10pvalue_freq001_order_melt.csv")
