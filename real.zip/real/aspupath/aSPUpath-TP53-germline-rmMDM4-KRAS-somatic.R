## TP53 germline remove MDM4 assocation with KRAS

library(data.table)
library(varhandle)
library("aSPU")
library(formattable)

# setwd("D:/Work/Wei/Data/Association/matrix012v2")
setwd("D:/Work/PhDThesis/data")

################################################### X data #########################################################
## read sample id 
tcga_sampleid <- fread("tcga.clean.sampleid", header = FALSE )
icgc_sampleid <- fread("icgc.clean.sampleid", header = FALSE)

## read annotated genes from oncotator 
tcga_oncotator <- fread("oncotator.tcga.useful.uniq.v2", fill = TRUE , header = TRUE)
icgc_oncotator <- fread("oncotator.icgc.useful.uniq.v2",fill = TRUE , header = TRUE)

## read pathways and genes in each pathway
# setwd("D:/Work/Wei/Data/Association")

pathway_dat <- read.csv("2019-4-16-pathway-gene-toUse.csv")
all_pathways <- sort(unique(pathway_dat$pathway))
pathway_genes <- unique(pathway_dat$gene)   ## 264

tcga_genes = unique(tcga_oncotator$Hugo_Symbol)
pathway_dat1 = pathway_dat[which(pathway_dat$gene %in% tcga_genes),]

# > dim(pathway_dat1)
# [1] 259  2
###############################################################################################

setwd("D:/Work/PhDThesis/data/2019-5-11aSPUpathPvalues")

p=9
  
pathway = all_pathways[p]
all_genes = pathway_dat1[pathway_dat1$pathway==pathway,]$gene

###### 2023-6-27 remove gene MDM4 from pathway TP53 ###### 
all_gemes_rm = all_genes[!all_genes %in% 'MDM4']

############################################ Assocation test #######################################################
## load data
rdata_aSPUpath = paste("2019-5-11-aSPUpath-germline",pathway,"-somaticDriver-association-pvalue.rdata",sep="")
load(rdata_aSPUpath)

## find rs numbers that correspond to the driver genes 
i_tcga <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% all_gemes_rm),]
i_tcga_rs <- i_tcga$dbSNP_RS 
i_tcga_rs1 <- unique(i_tcga_rs[i_tcga_rs != ""])  ## same


i_icgc <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% all_gemes_rm),]
i_icgc_rs <- i_icgc$dbSNP_RS 
i_icgc_rs1 <- unique(i_icgc_rs[i_icgc_rs != ""])  ## same 

############################################ Assocation test #######################################################
## gene info 
info <- tcga_oncotator[which(tcga_oncotator$dbSNP_RS %in% i_tcga_rs1),]

snp.info <- as.data.frame(info[,c(4,2,3)])

gene_id <- unique(info$Hugo_Symbol)

Chromosome <-c()
gene_start <- c()
gene_end<- c()
for (g in 1:length(gene_id)){
  Chromosome[g] <- unique(info[info$Hugo_Symbol==gene_id[g],]$Chromosome)
  gene_start[g] <- min(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
  #d1 <- dim(info[info$Hugo_Symbol==g,])[1]
  gene_end[g] <- max(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
} 

gene.info <- data.frame(gene_id,Chromosome,gene_start,gene_end)

g1 = c(1:8)

## calculate p value by permutation

################### all 156 genes from Y data: loop ##############################################################

date()
pvaspupath <- c()
for (j in 1:length(driver)){
  out <- aSPUpath(somatic_driver_order[,j], merged_data_i, snp.info = snp.info, gene.info = gene.info, model = "binomial", pow=g1, pow2=c(1,2,4,8), n.perm=1000)
  pvaspupath[j] <- out[length(out)]
}
date()

output <- data.frame(driver,pvaspupath)
output1 <- output[order(output$pvaspupath),]

csvname = paste("2023-6-27-aSPUpath-germline",pathway,"rmMDM4-somaticDriver-association-pvalue.csv",sep="")
write.csv(output1, file = csvname)

rdataname = paste("2023-6-27-aSPUpath-germline",pathway,"rmMDM4-somaticDriver-association-pvalue.rdata",sep="")
save(merged_data_i, somatic_driver, somatic_driver_order, driver, output1, file = rdataname)

