## test association between germline SNPs (pathway-based) and somatic mutation driver genes 
## all ten pathways
library(data.table)
library(varhandle)
library("aSPU")
library(formattable)

setwd("D:/Work/Wei/Data/Association/matrix012v2")

################################################### X data #########################################################
## read sample id 
tcga_sampleid <- fread("tcga.clean.sampleid", header = FALSE )
icgc_sampleid <- fread("icgc.clean.sampleid", header = FALSE)

## read annotated genes from oncotator 
tcga_oncotator <- fread("oncotator.tcga.useful.uniq.v2", fill = TRUE , header = TRUE)
icgc_oncotator <- fread("oncotator.icgc.useful.uniq.v2",fill = TRUE , header = TRUE)

## read pathways and genes in each pathway
setwd("D:/Work/Wei/Data/Association")

pathway_dat <- read.csv("2019-4-16-pathway-gene-toUse.csv")
all_pathways <- sort(unique(unfactor(pathway_dat$pathway)))
pathway_genes <- unfactor(unique(pathway_dat$gene))   ## 264

# tcga_oncotator_pathway <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% pathway_genes),]
# tcga_genes <- unique(tcga_oncotator_pathway$Hugo_Symbol)                                        ## same
# # [1] 258
# icgc_oncotator_pathway <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% pathway_genes),]
# icgc_genes <- unique(icgc_oncotator_pathway$Hugo_Symbol)                                        ## same
# [1] 258
#pathway_dat1 <- pathway_dat[which(unfactor(unique(pathway_dat$gene)) %in% tcga_genes),] # WRONG

tcga_genes = unique(tcga_oncotator$Hugo_Symbol)
pathway_dat1 = pathway_dat[which(pathway_dat$gene %in% tcga_genes),]

# > dim(pathway_dat1)
# [1] 259  2
###############################################################################################

overlapping <- read.table("overlapping_table.tsv",header = TRUE)
## read Y 
somatic <- read.csv("2019-3-30-somatic-sample-gene.csv")
rownames(somatic) <- somatic$X
somatic <- somatic[,-1]

#############################################################
## read driver gene list 
# driver_gene <- read.csv("2019-4-16-dirver-gene-toUse.csv")
driver_gene <- read.csv("2019-5-3-driver-gene-toUse.csv")
driver_gene1 <- driver_gene[,-1]
driver_gene2 <- unfactor(driver_gene1)
#############################################################

## select driver genes from Y data
somatic_driver <- somatic[, (names(somatic) %in% driver_gene2)]
dim(somatic_driver)
# [1] 2561  156

## based on X data sample id order Y data sample id according to overlapping table's donor id (function: ordery.r)
source("ordery.r")

for (p in 3:4){
  
  pathway = all_pathways[p]
  all_genes = unfactor(pathway_dat1[pathway_dat1$pathway==pathway,]$gene)
  
  ## find rs numbers that correspond to the driver genes 
  i_tcga <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% all_genes),]
  i_tcga_rs <- i_tcga$dbSNP_RS 
  i_tcga_rs1 <- unique(i_tcga_rs[i_tcga_rs != ""])  ## same
  
  
  i_icgc <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% all_genes),]
  i_icgc_rs <- i_icgc$dbSNP_RS 
  i_icgc_rs1 <- unique(i_icgc_rs[i_icgc_rs != ""])  ## same 
  
  # index_tcga <- c()
  # for (j in 1:length(i_tcga_rs1)){
  #   index_tcga[j] <- which(tcga_oncotator$dbSNP_RS %in% i_tcga_rs1[j]) 
  # }
  # 
  # index_icgc <- c()
  # for (j in 1:length(i_icgc_rs1)){
  #   index_icgc[j] <- which(icgc_oncotator$dbSNP_RS %in% i_icgc_rs1[j])
  # }
  
  index_tcga <- c()
  for (j in 1:length(i_tcga_rs1)){
    j1 = which(tcga_oncotator$dbSNP_RS %in% i_tcga_rs1[j])
    if (length(j1) > 1){j2 = j1[1]}
    else {j2 = j1}
    index_tcga[j] <- j2
  }
  
  index_icgc <- c()
  for (j in 1:length(i_icgc_rs1)){
    j1 = which(icgc_oncotator$dbSNP_RS %in% i_icgc_rs1[j])
    if (length(j1) > 1){j2 = j1[1]}
    else {j2 = j1}
    index_icgc[j] <- j2
  }
  
  setwd("D:/Work/Wei/Data/Association/matrix012v2")
  ## read X matrix from tcga
  
  # tcga10_109 <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_10_109v2.out")
  # colnames(tcga10_109) <- tcga_oncotator$dbSNP_RS
  # tcga10_109_rs <- tcga10_109[,..i_tcga_rs]
  
  date()
  
  tcga10_109_rs <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_10_109v2.out")[,..index_tcga]
  tcga110_209_rs <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_110_209v2.out")[,..index_tcga]
  tcga210_309_rs <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_210_309v2.out")[,..index_tcga]
  tcga310_409_rs <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_310_409v2.out")[,..index_tcga]
  tcga410_509_rs <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_410_509v2.out")[,..index_tcga]
  tcga510_609_rs <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_510_609v2.out")[,..index_tcga]
  tcga610_709_rs <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_610_709v2.out")[,..index_tcga]
  tcga710_795_rs <- fread("SNPs.only.tcga.white.rmsexXY.overlapId.freq005.matrix_710_795v2.out")[,..index_tcga]
  
  
  merged_tcga <- rbind(tcga10_109_rs,tcga110_209_rs,tcga210_309_rs,tcga310_409_rs,tcga410_509_rs,
                       tcga510_609_rs,tcga610_709_rs,tcga710_795_rs)
  merged_tcga_df <- as.data.frame(merged_tcga)
  
  rownames(merged_tcga_df) <- tcga_sampleid$V1
  
  ## read X matrix from icgc
  icgc10_109_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_10_109v2.out")[,..index_icgc]
  icgc110_209_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_110_209v2.out")[,..index_icgc]
  icgc210_309_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_210_309v2.out")[,..index_icgc]
  icgc310_409_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_310_409v2.out")[,..index_icgc]
  icgc410_509_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_410_509v2.out")[,..index_icgc]
  icgc510_609_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_510_609v2.out")[,..index_icgc]
  icgc610_709_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_610_709v2.out")[,..index_icgc]
  icgc710_809_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_710_809v2.out")[,..index_icgc]
  icgc810_909_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_810_909v2.out")[,..index_icgc]
  icgc910_1009_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_910_1009v2.out")[,..index_icgc]
  icgc1010_1109_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_1010_1109v2.out")[,..index_icgc]
  icgc1110_1209_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_1110_1209v2.out")[,..index_icgc]
  icgc1210_1309_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_1210_1309v2.out")[,..index_icgc]
  icgc1310_1409_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_1310_1409v2.out")[,..index_icgc]
  icgc1410_1509_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_1410_1509v2.out")[,..index_icgc]
  icgc1510_1609_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_1510_1609v2.out")[,..index_icgc]
  icgc1610_1709_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_1610_1709v2.out")[,..index_icgc]
  icgc1710_1784_rs <- fread("SNPs.only.icgc.white.rmsexXY.overlapId.freq005.matrix_1710_1784v2.out")[,..index_icgc]
  
  merged_icgc <- rbind(icgc10_109_rs,icgc110_209_rs,icgc210_309_rs,icgc310_409_rs,icgc410_509_rs,
                       icgc510_609_rs,icgc610_709_rs,icgc710_809_rs,icgc810_909_rs,icgc910_1009_rs,
                       icgc1010_1109_rs,icgc1110_1209_rs,icgc1210_1309_rs,icgc1310_1409_rs,
                       icgc1410_1509_rs,icgc1510_1609_rs,icgc1610_1709_rs,icgc1710_1784_rs)
  
  merged_icgc_df <- as.data.frame(merged_icgc)
  
  rownames(merged_icgc_df) <- icgc_sampleid$V1
  
  
  ## merge tcga and icgc 
  merged_data_i <- rbind(merged_tcga_df,merged_icgc_df)
  
  ## add column names (rs number)  to X matrix
  colnames(merged_data_i) <- i_tcga_rs1
  
  date()
  
  ############################################# Y data ##############################################################
  setwd("D:/Work/Wei/Data/Association")
  
  yorder = ordery(rownames(merged_data_i),rownames(somatic_driver),overlapping)
  somatic_driver_order = somatic_driver[yorder,]
  
  # driver <- sort(colnames(somatic_driver_order))
  driver <- colnames(somatic_driver_order)
  length(driver)
  
  ############################################ Assocation test #######################################################
  
  g1 = c(1:8)
  
  ## calculate p value by permutation
  
  ################### all 154 genes from Y data: loop ##############################################################
  info <- tcga_oncotator[which(tcga_oncotator$dbSNP_RS %in% i_tcga_rs1),]
  
  snp.info <- as.data.frame(info[,c(4,2,3)])
  
  gene_id <- unique(info$Hugo_Symbol)
  
  Chromosome <-c()
  gene_start <- c()
  gene_end<- c()
  for (g in 1:length(gene_id)){
    Chromosome[g] <- unique(info[info$Hugo_Symbol==gene_id[g],]$Chromosome)
    gene_start[g] <- min(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
    #d1 <- dim(info[info$Hugo_Symbol==g,])[1]
    gene_end[g] <- max(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
  } 
  
  gene.info <- data.frame(gene_id,Chromosome,gene_start,gene_end)
  
  date()
  pvaspupath <- c()
  for (j in 1:length(driver)){
    out <- aSPUpath(somatic_driver_order[,j], merged_data_i, snp.info = snp.info, gene.info = gene.info, model = "binomial", pow=g1, pow2=c(1,2,4,8), n.perm=1000)
    pvaspupath[j] <- out[length(out)]
  }
  date()
  
  output <- data.frame(driver,pvaspupath)
  output1 <- output[order(output$pvaspupath),]
  
  csvname = paste("2019-5-5-aSPUpath-germline",pathway,"-somaticDriver-association-pvalue.csv",sep="")
  write.csv(output1, file = csvname)
  
  rdataname = paste("2019-5-5-aSPUpath-germline",pathway,"-somaticDriver-association-pvalue.rdata",sep="")
  save(merged_data_i, somatic_driver, somatic_driver_order, driver, output1, file = rdataname)
}
