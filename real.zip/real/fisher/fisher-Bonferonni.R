## fisher exact test Bonferonni correction 

library(data.table)
library(varhandle)


## combine fisher p values results 
setwd("D:/Work/Wei/Data/Association")
all_genes <- read.csv("2019-5-4-germline_all_genes.csv",stringsAsFactors = FALSE)
all_genes1 <- all_genes[,-1]

setwd("D:/Work/Wei/Data/Association/2019-5-4fisherPvalues")

output <- data.frame(matrix(vector(), 156, 0,),stringsAsFactors=F)
names <- c()
snp_num <- c()
for (i in 1: length(all_genes1)){
  gene = all_genes1[i]
  
  ## read p values from fisher tests
  i_file <- read.csv(paste("2019-5-3-fisher-germline",gene,"-somaticDriver-association-pvalue.csv",sep=""))
  i_file1 <- i_file[,-1]
  
  ## load rdata from fisher tests to get number of snps in one gene
  load(paste("2019-5-3-fisher-germline",gene,"-somaticDriver-association-pvalue.rdata",sep=""))
  num <- dim(merged_data_i)[2]
  
  snp_num <- c(snp_num, num)
  
  ## bonferroni correction with number of snps in each germline gene
  p <- i_file1[,2]
  
  padjust <- c()
  for (j in 1:length(p)){
    padjust[j] = p.adjust(p[j], method = "bonferroni", n = num)
  }
  
  names <- c(names,"somatic",gene)
  
  f1 <- data.frame(i_file1[,1],padjust)
  colnames(f1) <- c("somatic",gene)
  
  output <- cbind(output, f1)
}

snp_num <- data.frame(all_genes1,snp_num)

write.csv(output, file = "2019-5-5-fisher-germline-somaticDriver-association-bonferroni.csv")
write.csv(snp_num, file = "2019-5-5-fisher-numberSNPinGene.csv")







