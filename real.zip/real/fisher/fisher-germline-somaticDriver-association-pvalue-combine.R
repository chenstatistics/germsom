## combine fisher p values results

setwd("D:/Work/Wei/Data/Association")
all_genes <- read.csv("2019-5-4-germline_all_genes.csv",stringsAsFactors = FALSE)
all_genes1 <- all_genes[,-1]


setwd("D:/Work/Wei/Data/Association/2019-5-4fisherPvalues")

output <- matrix(, nrow = 156, ncol = 0)
for (i in 1: length(all_genes1)){
  gene = all_genes1[i]
  i_file <- read.csv(paste("2019-5-3-fisher-germline",gene,"-somaticDriver-association-pvalue.csv",sep=""))
  i_file1 <- i_file[,-1]
  colnames(i_file1) <- c("somatic",gene)
  output <- cbind(output, i_file1)
}

write.csv(output, file = "2019-5-5-fisher-germline-somaticDriver-association-pvalue.csv")

