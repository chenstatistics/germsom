## GatesSimes multiple testing correction: FDR 

library(data.table)
library(varhandle)
library(gplots)

# setwd("D:/Work/Wei/Data/Association/2019-5-11aSPUpathPvalues")
setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/Data/GatesSimes")

########### read p values from aSPU assciation test results 2019-5-11 (combined 2019-5-13) #############
pval <- read.csv("2023-7-5-GS-germline-somaticDriver-association-pvalue_order.csv")
rownames(pval) <- pval$X
pval <- pval[,-1]        ## each row is somatic mutation gene, each column is pathway (156 by 10)  
sum(pval<0.05)
# [1] 259

################################# FDR correction ###################################################
# p.adjust(p, method = p.adjust.methods, n = length(p))
# p.adjust.methods: c("holm", "hochberg", "hommel", "bonferroni", "BH", "BY","fdr", "none")

fdr_matrix <- matrix(p.adjust(as.vector(as.matrix(pval)), method='fdr'),ncol=10)

sum(fdr_matrix<0.2)
# [1] 146
sum(fdr_matrix<0.1)
# [1] 84
sum(fdr_matrix<0.05)
# [1] 41
sum(fdr_matrix<0.01)
# [1] 23
sum(fdr_matrix<0.001)
# [1] 13
sum(fdr_matrix<0.0001)
# [1] 12

fdr_matrix_df <- as.data.frame(fdr_matrix)
rownames(fdr_matrix_df) <- rownames(pval)
colnames(fdr_matrix_df) <- colnames(pval)

# write.csv(fdr_matrix_df, file = "2023-7-5-GS-germline-somaticDriver-association-fdr.csv")


##################################### Heatmap #######################################################
## -log10(pvalues) --- color
## box --- fdr < 0.2
## only inclued genes whose frequency is greater or equal to 1% (57genes)

## select genes 
gene_freq001 <- read.csv("2019-5-7-driver-gene-freq001.csv")
gene_freq001 <- gene_freq001[,-1]
# gene_freq001 <- unfactor(gene_freq001)  ## 59 genes

pval_freq001 <- pval[which(rownames(pval) %in% gene_freq001),]  
pval_freq001_mtx <- as.matrix(pval_freq001)
pval_freq001_mtx1 <- -log10(pval_freq001_mtx + 10^-6)

## heatmap p values for genes whose frequency greater or equal to 0.01
pdf(file = "2023-7-5-GS-germline-somatic-association-freq001_genes-pvalues.pdf", 20, 17)

lwid = c(1.2,2)
lhei = c(1.5,12,4)
lmat = rbind(c(0,3),c(2,1),c(0,4))

heatmap.2(pval_freq001_mtx1,col=bluered(100),scale="none", key=TRUE,breaks=seq(0, 6, length.out=101),margin=c(8, 12),cexCol = 2.5,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=1.8,lmat = lmat, lwid = lwid, lhei = lhei, keysize=1, key.par = list(cex=1.5))  ##  Colv: do not reorder column
dev.off()


## heatmap p values for all genes
pval_mtx <- as.matrix(pval)
pval_mtx1 <- -log10(pval_mtx + 10^-6)

pdf(file = "2023-7-5-GS-germline-somatic-association-all_genes-pvalues.pdf", 20, 17)
heatmap.2(pval_mtx1,col=bluered(100),scale="none", key=TRUE,breaks=seq(0, 6, length.out=101),margin=c(8, 12),cexCol = 2.5,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=0.5)  ##  Colv: do not reorder column
dev.off()


## heatmal fdr for genes whose frequency greater or equal to 0.01
fdr_matrix_df_freq001 <- fdr_matrix_df[which(rownames(fdr_matrix_df) %in% gene_freq001),]

fdr_matrix_df_freq001_mtx <- as.matrix(fdr_matrix_df_freq001)
fdr_matrix_df_freq001_mtx1 <- -log10(fdr_matrix_df_freq001_mtx + 10^-6)

pdf(file = "2023-7-5-GS-germline-somatic-association-freq001_genes-fdr.pdf", 20, 17)
heatmap.2(fdr_matrix_df_freq001_mtx1,col=bluered(100),scale="none", key=TRUE,breaks=seq(0, 6, length.out=101),margin=c(8, 12),cexCol = 2.5,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=1.8,lmat = lmat, lwid = lwid, lhei = lhei, keysize=0.75, key.par = list(cex=1.5))  ##  Colv: do not reorder column
dev.off()


## heatmal fdr for all genes 
fdr_matrix_df_mtx <- as.matrix(fdr_matrix_df)
fdr_matrix_df_mtx1 <- -log10(fdr_matrix_df_mtx + 10^-6)

pdf(file = "2023-7-5-GS-germline-somatic-association-all_genes-fdr.pdf", 20, 17)
heatmap.2(fdr_matrix_df_mtx1,col=bluered(100),scale="none", key=TRUE,breaks=seq(0, 6, length.out=101),margin=c(8, 12),cexCol = 2.5,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=0.5)  ##  Colv: do not reorder column
dev.off()

