## combine p values from HYST tests

# setwd("D:/Work/Wei/Data/Association")
setwd("D:/Work/PhDThesis/data")

all_pathways <- read.csv("2019-5-7-germline_all_pathways.csv",stringsAsFactors = FALSE)
all_pathways1 <- all_pathways[,-1]

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/Data/HYST")

output <- matrix(, nrow = 156, ncol = 0)
for (i in 1: length(all_pathways1)){
  pathway = all_pathways1[i]
  i_file <- read.csv(paste("2023-6-29-HYST-germline",pathway,"-somaticDriver-association-pvalue.csv",sep=""))
  i_file1 <- i_file[,-1]
  colnames(i_file1) <- c("somatic",pathway)
  output <- cbind(output, i_file1)
}

write.csv(output, file = "2023-7-5-HYST-germline-somaticDriver-association-pvalue.csv")


output_sort <- matrix(, nrow = 156, ncol = 0)
for (i in 1: length(all_pathways1)){
  pathway = all_pathways1[i]
  i_file <- read.csv(paste("2023-6-29-HYST-germline",pathway,"-somaticDriver-association-pvalue.csv",sep=""))
  i_file1 <- i_file[,-1]
  colnames(i_file1) <- c("somatic",pathway)
  
  p = order(i_file1[,1])
  c2 = i_file1[,2]
  c2 = c2[p]
  
  output_sort <- cbind(output_sort, c2)
}

rownames(output_sort) = sort(i_file1[,1])
colnames(output_sort) = all_pathways1

output_order = output_sort[,order(colnames(output_sort))]

write.csv(output_order, file = "2023-7-5-HYST-germline-somaticDriver-association-pvalue_order.csv")
