## test association between germline SNPs (pathway-based) and somatic mutation driver genes 
## all ten pathways
## HYST

library(data.table)
library(varhandle)
library("aSPU")
library(formattable)

# setwd("D:/Work/Wei/Data/Association/matrix012v2")
setwd("D:/Work/PhDThesis/data")

################################################### X data #########################################################
## read sample id 
tcga_sampleid <- fread("tcga.clean.sampleid", header = FALSE )
icgc_sampleid <- fread("icgc.clean.sampleid", header = FALSE)

## read annotated genes from oncotator 
tcga_oncotator <- fread("oncotator.tcga.useful.uniq.v2", fill = TRUE , header = TRUE)
icgc_oncotator <- fread("oncotator.icgc.useful.uniq.v2",fill = TRUE , header = TRUE)

## read pathways and genes in each pathway
# setwd("D:/Work/Wei/Data/Association")

pathway_dat <- read.csv("2019-4-16-pathway-gene-toUse.csv")
all_pathways <- sort(unique(pathway_dat$pathway))
pathway_genes <- unique(pathway_dat$gene)   ## 264

tcga_genes = unique(tcga_oncotator$Hugo_Symbol)
pathway_dat1 = pathway_dat[which(pathway_dat$gene %in% tcga_genes),]

# > dim(pathway_dat1)
# [1] 259  2
###############################################################################################

setwd("D:/Work/PhDThesis/data/2019-5-11aSPUpathPvalues")

# for (p in 1:2){
p = 6
pathway = all_pathways[p]
all_genes = pathway_dat1[pathway_dat1$pathway==pathway,]$gene

############################################ Assocation test #######################################################
## load data
rdata_aSPUpath = paste("2019-5-11-aSPUpath-germline",pathway,"-somaticDriver-association-pvalue.rdata",sep="")
load(rdata_aSPUpath)

## find rs numbers that correspond to the driver genes 
i_tcga <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% all_genes),]
i_tcga_rs <- i_tcga$dbSNP_RS 
i_tcga_rs1 <- unique(i_tcga_rs[i_tcga_rs != ""])  ## same


i_icgc <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% all_genes),]
i_icgc_rs <- i_icgc$dbSNP_RS 
i_icgc_rs1 <- unique(i_icgc_rs[i_icgc_rs != ""])  ## same 

## gene info 
info <- tcga_oncotator[which(tcga_oncotator$dbSNP_RS %in% i_tcga_rs1),]

snp.info <- as.data.frame(info[,c(4,2,3)])

gene_id <- unique(info$Hugo_Symbol)

Chromosome <-c()
gene_start <- c()
gene_end<- c()
for (g in 1:length(gene_id)){
  Chromosome[g] <- unique(info[info$Hugo_Symbol==gene_id[g],]$Chromosome)
  gene_start[g] <- min(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
  #d1 <- dim(info[info$Hugo_Symbol==g,])[1]
  gene_end[g] <- max(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
} 

gene.info <- data.frame(gene_id,Chromosome,gene_start,gene_end)

############################## HYST ###############################
## read p-values from outside file
setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/Data")
snp.pvalues = read.table("20230629pvalues.pathway6.txt", header = TRUE)
snp.pvalues1 = snp.pvalues[!duplicated(snp.pvalues$rsid),]
snp.pvalues2 = na.omit(snp.pvalues1)

## remove snps with p-values = NA 
na.rsid = setdiff(snp.pvalues1$rsid,snp.pvalues2$rsid)
length(na.rsid)   ### [1] 22

merged_data_i1 = merged_data_i[,-which(names(merged_data_i) %in% na.rsid)]
snp.info1 = snp.info[-which(snp.info$dbSNP_RS %in% na.rsid),]

date()
pvhyst <- c()
for (j in 1:length(driver)){
# for (j in 1:2){
  if (j %% 10 == 0) {message (j,': ', date())}

  ## get correlation of SNPs
  ldmat <- cor(merged_data_i1)
  
  pvhyst[j] <- Hyst(pvec = snp.pvalues2[,j], ldmatrix = ldmat, snp.info = snp.info1,gene.info = gene.info)
}
date()

output <- data.frame(driver,pvhyst)
output1 <- output[order(output$pvhyst),]

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/Data")

csvname = paste("2023-6-29-HYST-germline",pathway,"-somaticDriver-association-pvalue.csv",sep="")
write.csv(output1, file = csvname)

rdataname = paste("2023-6-29-HYST-germline",pathway,"-somaticDriver-association-pvalue.rdata",sep="")
save(merged_data_i, merged_data_i1, somatic_driver, somatic_driver_order, driver, snp.info, snp.info1, 
     gene.info, snp.pvalues, snp.pvalues1, snp.pvalues2, output1, file = rdataname)

