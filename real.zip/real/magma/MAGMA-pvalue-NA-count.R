### Count the number of NA p-values for single SNP association test

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA/20230621gene.Allsom.genes.out")

### for gene analysis
dat = read.table("20230621pvalues.gene.txt", header = TRUE)
dat1 = dat[!duplicated(dat$rsid),]   ### [1] 18331   157
sum(is.na(dat1))   ### [1] 9516
#18331*156 = 2859636
# 9516/2859636  ## [1] 0.003327696 (0.33% NA p-values)

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA/20230629set.pathwayAllsom.gsa.out")

### for gene-set analysis 
datp1 = read.table("20230629pvalues.pathway1.txt", header = TRUE)
datp1p = datp1[!duplicated(datp1$rsid),]
datp2 = read.table("20230629pvalues.pathway2.txt", header = TRUE)
datp2p = datp2[!duplicated(datp2$rsid),]
datp3 = read.table("20230629pvalues.pathway3.txt", header = TRUE)
datp3p = datp3[!duplicated(datp3$rsid),]
datp4 = read.table("20230629pvalues.pathway4.txt", header = TRUE)
datp4p = datp4[!duplicated(datp4$rsid),]
datp5 = read.table("20230629pvalues.pathway5.txt", header = TRUE)
datp5p = datp5[!duplicated(datp5$rsid),]
datp6 = read.table("20230629pvalues.pathway6.txt", header = TRUE)
datp6p = datp6[!duplicated(datp6$rsid),]
datp7 = read.table("20230629pvalues.pathway7.txt", header = TRUE)
datp7p = datp7[!duplicated(datp7$rsid),]
datp8 = read.table("20230629pvalues.pathway8.txt", header = TRUE)
datp8p = datp8[!duplicated(datp8$rsid),]
datp9 = read.table("20230629pvalues.pathway9.txt", header = TRUE)
datp9p = datp9[!duplicated(datp9$rsid),]
datp10 = read.table("20230629pvalues.pathway10.txt", header = TRUE)
datp10p = datp10[!duplicated(datp10$rsid),]

## total number of p-values
de = (dim(datp1p)[1]+dim(datp2p)[1]+dim(datp3p)[1]+dim(datp4p)[1]+dim(datp5p)[1]+
  dim(datp6p)[1]+dim(datp7p)[1]+dim(datp8p)[1]+dim(datp9p)[1]+dim(datp10p)[1])*156
# [1] 6504420

nu = sum(is.na(datp1p))+sum(is.na(datp2p))+sum(is.na(datp3p))+sum(is.na(datp4p))+sum(is.na(datp5p))+
  sum(is.na(datp6p))+sum(is.na(datp7p))+sum(is.na(datp8p))+sum(is.na(datp9p))+sum(is.na(datp10p))
# [1] 30888

p.na = nu/de
# [1] 0.004748771
