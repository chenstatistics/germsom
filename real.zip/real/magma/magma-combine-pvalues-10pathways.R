setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA")

pvpath1 = read.table("20230629pvalues.pathway1.txt", header = TRUE)
pvpath2 = read.table("20230629pvalues.pathway2.txt", header = TRUE)
pvpath3 = read.table("20230629pvalues.pathway3.txt", header = TRUE)
pvpath4 = read.table("20230629pvalues.pathway4.txt", header = TRUE)
pvpath5 = read.table("20230629pvalues.pathway5.txt", header = TRUE)
pvpath6 = read.table("20230629pvalues.pathway6.txt", header = TRUE)
pvpath7 = read.table("20230629pvalues.pathway7.txt", header = TRUE)
pvpath8 = read.table("20230629pvalues.pathway8.txt", header = TRUE)
pvpath9 = read.table("20230629pvalues.pathway9.txt", header = TRUE)
pvpath10 = read.table("20230629pvalues.pathway10.txt", header = TRUE)

compv = rbind(pvpath1,pvpath2,pvpath3,pvpath4,pvpath5,pvpath6,pvpath7,pvpath8,pvpath9,pvpath10)

write.table(compv, file = "20230629pvalues.pathwayAll.txt", sep = "\t",row.names = FALSE, col.names = TRUE, quote = FALSE)

## insert last column (rsid) into first column
compvmod = read.table("20230629pvalues.pathwayAllmod.txt",header = TRUE)
