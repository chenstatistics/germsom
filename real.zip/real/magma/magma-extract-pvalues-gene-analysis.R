library(data.table)
library(tidyr)

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA")

dat1 = read.table("20230621pvalues.gene.txt", sep = "\t", header = TRUE)
somatic_driver = colnames(dat)[2:157]

dat2 = read.csv("20230621annote.gene.genes.annot.txt.GENE.csv")

germline_gene = dat2$GENE

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA/20230621gene.Allsom.genes.out")

files = list.files(pattern="genes.out.txt")

pvmtx <- matrix(, nrow = 149, ncol = 156)
for (i in 2: (length(files)+1)){
  pvmtx[,i-1] <- read.table(paste("20230621gene.Allsom",i,".genes.out.txt", sep = ""), header = TRUE)$P
}
rownames(pvmtx) = germline_gene
colnames(pvmtx) = somatic_driver
dim(pvmtx)   ### [1] 149 156 (after annotation by magma, germline genes number lose one)

# write.csv(pvmtx, file = "2023-6-26-magma-gene-analysis-pvalues-germlineGene-by-somatic.csv")

###### fdr 

###### heatmap 