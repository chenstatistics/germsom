library(data.table)
library(tidyr)

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA/20230629set.pathwayAllsom.gsa.out")

###### read data: pathway and somatic driver
dat_pathway = read.csv("20230629set.pathwayAllsom.gsa.out.PATHWAY.csv",header = FALSE)
pathway = unique(dat_pathway$V1)

dat_somatic = read.table("20230629pvalues.pathwayAllmod.txt", sep = "\t", header = TRUE)
somatic_driver = colnames(dat_somatic)[2:157]

###### combine p values result from magma gene set analysis 
files = list.files(pattern="gsa.out.txt")

pvmtx <- matrix(, nrow = 10, ncol = 156)
for (i in 2: (length(files)+1)){
  pvmtx[,i-1] <- read.table(paste("20230629set.pathwayAllsom",i,".gsa.out.txt", sep = ""), header = TRUE)$P
}
pvmtx1 = as.data.frame(pvmtx)

rownames(pvmtx1) = pathway
colnames(pvmtx1) = somatic_driver
dim(pvmtx)   ### [1] 10 156 (row: 10 pathway; column: 156 somatic mutation genes)

write.csv(pvmtx1, file = "2023-6-29-magma-gene-set-analysis-pvalues-germlinePathway-by-somatic.csv")

###### fdr 

###### heatmap 