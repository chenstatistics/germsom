## magma gene analysis input preparation

library(data.table)
library(varhandle)
library("aSPU")

setwd("D:/Work/PhDThesis/data")

## read annotated genes from oncotator 
tcga_oncotator <- fread("oncotator.tcga.useful.uniq.v2", fill = TRUE , header = TRUE)
icgc_oncotator <- fread("oncotator.icgc.useful.uniq.v2",fill = TRUE , header = TRUE)

## read driver gene list 
driver_gene <- read.csv("2019-5-3-driver-gene-toUse.csv")
driver_gene1 <- driver_gene[,-1]

tcga_oncotator_driver <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% driver_gene1),]
tcga_genes = unique(tcga_oncotator_driver$Hugo_Symbol)
# [1] 150

icgc_oncotator_driver <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% driver_gene1),]
icgc_genes = unique(icgc_oncotator_driver$Hugo_Symbol)
# [1] 150

all.equal(tcga_genes,icgc_genes) # same

all_genes = tcga_genes # same

###### sns info, gene info
snp.info = c()
gene.info = c()
for (i in 1:150){
# for (i in 1:3){
  gene = all_genes[i]
  
  ## find rs numbers that correspond to the driver genes 
  i_tcga <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol == gene),]
  i_tcga_rs <- i_tcga$dbSNP_RS 
  i_tcga_rs1 <- unique(i_tcga_rs[i_tcga_rs != ""])
  
  info <- tcga_oncotator[which(tcga_oncotator$dbSNP_RS %in% i_tcga_rs1),]
  s <- as.data.frame(info[,c(4,2,3)])
  snp.info = rbind(snp.info,s)

  gene_id <- unique(info$Hugo_Symbol)

  Chromosome <-c()
  gene_start <- c()
  gene_end<- c()
  for (g in 1:length(gene_id)){
    Chromosome[g] <- unique(info[info$Hugo_Symbol==gene_id[g],]$Chromosome)
    gene_start[g] <- min(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
    gene_end[g] <- max(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
  } 
  g <- data.frame(gene_id,Chromosome,gene_start,gene_end)
  gene.info = rbind(gene.info,g)
}

###### p values 
driver_gene <- read.csv("2019-5-3-driver-gene-toUse.csv")
driver_gene1 <- driver_gene[,-1]

tcga_oncotator_driver <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% driver_gene1),]
tcga_genes = unique(tcga_oncotator_driver$Hugo_Symbol)
# [1] 150

icgc_oncotator_driver <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% driver_gene1),]
icgc_genes = unique(icgc_oncotator_driver$Hugo_Symbol)
# [1] 150

all.equal(tcga_genes,icgc_genes) # same

all_genes = tcga_genes # same  150

setwd("D:/Work/PhDThesis/data/2019-5-8aSPUpvalues")

date()
outputpv =  matrix(NA, ncol = 156)
for (i in 1:150){
# for (i in 1:3){
  gene = all_genes[i]

  rdata_aSPU = paste("2019-5-8-germline",gene,"-somaticDriver-association-pvalue.rdata",sep="")
  load(rdata_aSPU)
  
  pmtx = matrix(NA,nrow=dim(merged_data_i)[2],ncol=156)  
  ## row: # snps in one gene; column: 156 somatic mutation genes
  for (j in 1:156) {
    for (s in 1:dim(merged_data_i)[2]){
      fit = glm(somatic_driver_order[,j] ~ merged_data_i[,s], family=binomial) 
      a <- summary(fit)
      b <- coef(a)
      d <- a$aliased
      e <- matrix(nrow = length(d), ncol = ncol(b),
                  dimnames = list(names(d), dimnames(b)[[2]]))
      ## fill rows for non-aliased variables
      e[!d] <- b
      pmtx[s,j] <- e[2,4]
      # if (is.na(coef(summary(fit))[2,4])) { pmtx[s,j] = NA }
      # if (!is.na(coef(summary(fit))[2,4])) { pmtx[s,j] = coef(summary(fit))[2,4] }
    }
  }

  # logitp <- getlogitp1(somatic_driver_order[,1], merged_data_i)
  outputpv = rbind(outputpv,pmtx)
}
outputpv1 = outputpv[-1,]
pvalues = cbind(unique(snp.info[,1]),outputpv1)  ## [1] 18331   157 (18331 snps, 156 somatic mutation genes)
date()
colnames(pvalues) = c("rsid",colnames(somatic_driver_order))

###### 
snp.info1 = snp.info[!duplicated(snp.info$dbSNP_RS),]   ## [1] 18331     3

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA")
write.table(snp.info1, file = "20230621snps.gene.txt", sep = "\t",row.names = FALSE, col.names = TRUE, quote = FALSE)
write.table(gene.info, file = "20230621gene.gene.txt", sep = "\t",row.names = FALSE, col.names = TRUE, quote = FALSE)
write.table(pvalues, file = "20230621pvalues.gene.txt", sep = "\t",row.names = FALSE, col.names = TRUE, quote = FALSE)
