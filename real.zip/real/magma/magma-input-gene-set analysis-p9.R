## magma input for gene-set analysis

library(data.table)
setwd("D:/Work/PhDThesis/data")

## read annotated genes from oncotator 
tcga_oncotator <- fread("oncotator.tcga.useful.uniq.v2", fill = TRUE , header = TRUE)
icgc_oncotator <- fread("oncotator.icgc.useful.uniq.v2",fill = TRUE , header = TRUE)

## read pathways and genes in each pathway
# setwd("D:/Work/Wei/Data/Association")

pathway_dat <- read.csv("2019-4-16-pathway-gene-toUse.csv")
all_pathways <- sort(unique(pathway_dat$pathway))
pathway_genes <- unique(pathway_dat$gene)   ## 264

tcga_genes = unique(tcga_oncotator$Hugo_Symbol)
pathway_dat1 = pathway_dat[which(pathway_dat$gene %in% tcga_genes),]

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA")
# write.table(pathway_dat1, file = "20230616germlinepathway.txt", sep = "\t",row.names = FALSE, col.names = FALSE, quote = FALSE)

######
p = 9
  
pathway = all_pathways[p]
all_genes = pathway_dat1[pathway_dat1$pathway==pathway,]$gene

## find rs numbers that correspond to the driver genes 
i_tcga <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% all_genes),]
i_tcga_rs <- i_tcga$dbSNP_RS 
i_tcga_rs1 <- unique(i_tcga_rs[i_tcga_rs != ""])  ## same


i_icgc <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% all_genes),]
i_icgc_rs <- i_icgc$dbSNP_RS 
i_icgc_rs1 <- unique(i_icgc_rs[i_icgc_rs != ""])  ## same 

info <- tcga_oncotator[which(tcga_oncotator$dbSNP_RS %in% i_tcga_rs1),]

## snp info 
snp.info <- as.data.frame(info[,c(4,2,3)])

gene_id <- unique(info$Hugo_Symbol)

Chromosome <-c()
gene_start <- c()
gene_end<- c()
for (g in 1:length(gene_id)){
  Chromosome[g] <- unique(info[info$Hugo_Symbol==gene_id[g],]$Chromosome)
  gene_start[g] <- min(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
  #d1 <- dim(info[info$Hugo_Symbol==g,])[1]
  gene_end[g] <- max(info[info$Hugo_Symbol==gene_id[g],]$Start_position)
} 

## gene info 
gene.info <- data.frame(gene_id,Chromosome,gene_start,gene_end)

######
setwd("D:/Work/PhDThesis/data/2019-5-11aSPUpathPvalues")

###### load data 
## (SNP matrix for all genes in a pathway and somatic mutation matrix for 156 driver genes)
rdata_aSPUpath = paste("2019-5-11-aSPUpath-germline",pathway,"-somaticDriver-association-pvalue.rdata",sep="")
load(rdata_aSPUpath)
## merged_data_i [1] 2561 1066

date() 
pmtx =  matrix(,nrow = dim(snp.info)[1], ncol = 156)
for (i in 1:dim(merged_data_i)[2]){
  ## row: # snps in one pathway; column: 156 somatic mutation genes
  if (i %% 100 == 0) {message (i,': ',date())}
  for (j in 1:156) {
    fit = glm(somatic_driver_order[,j] ~ merged_data_i[,i], family=binomial) 
    a <- summary(fit)
    b <- coef(a)
    d <- a$aliased
    e <- matrix(nrow = length(d), ncol = ncol(b),
                dimnames = list(names(d), dimnames(b)[[2]]))
    ## fill rows for non-aliased variables
    e[!d] <- b
    pmtx[i,j] <- e[2,4]
  }
}
date() 

pmtx1 = as.data.frame(pmtx)

pmtx1$rsid = colnames(merged_data_i)

colnames(pmtx1) = c(colnames(somatic_driver_order),'rsid')

###### 
setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/MAGMA")
write.table(snp.info, file = "20230629snps.pathway9.txt", sep = "\t",row.names = FALSE, col.names = TRUE, quote = FALSE)
write.table(gene.info, file = "20230629gene.pathway9.txt", sep = "\t",row.names = FALSE, col.names = TRUE, quote = FALSE)
write.table(pmtx1, file = "20230629pvalues.pathway9.txt", sep = "\t",row.names = FALSE, col.names = TRUE, quote = FALSE)

## gene set for a pathway
set = pathway_dat1[pathway_dat1$pathway==pathway,]
write.table(set, file = "20230629set.pathway9.txt", sep = "\t",row.names = FALSE, col.names = TRUE, quote = FALSE)
