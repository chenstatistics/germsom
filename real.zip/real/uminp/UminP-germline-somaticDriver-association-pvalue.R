## UminP

# setwd("D:/Work/Wei/Data/Association")
setwd("D:/Work/PhDThesis/data")

all_genes <- read.csv("2019-5-4-germline_all_genes.csv",stringsAsFactors = FALSE)
all_genes1 <- all_genes[,-1]
  
setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/Data/UminP")

files = list.files(pattern="*.csv")

output <- matrix(, nrow = 156, ncol = 0)
for (i in 1: length(files)){
  gene = all_genes1[i]
  i_file <- read.csv(paste("2023-5-17-UminP-germline",gene,"-somaticDriver-association-pvalue.csv",sep=""))
  i_file1 <- i_file[,-1]
  colnames(i_file1) <- c("somatic",gene)
  output <- cbind(output, i_file1)
}

# # First apply read.csv, then cbind
# myfiles = do.call(cbind, lapply(files, function(x) read.csv(x, stringsAsFactors = FALSE)))

# myfiles1 <- myfiles[,-seq(1, ncol(myfiles), 3)]
# colnames(myfiles1)[seq(1, ncol(myfiles1), 2)] <- "somatic"
# colnames(myfiles1)[seq(2, ncol(myfiles1), 2)] <- gene


write.csv(output, file = "2023-5-17-UminP-germline-somaticDriver-association-pvalue.csv")

####################################################################################################
output_sort <- matrix(, nrow = 156, ncol = 0)
for (i in 1: length(files)){
  gene = all_genes1[i]
  i_file <- read.csv(paste("2023-5-17-UminP-germline",gene,"-somaticDriver-association-pvalue.csv",sep=""))
  i_file1 <- i_file[,-1]
  colnames(i_file1) <- c("somatic",gene)
  
  p = order(i_file1[,1])
  c2 = i_file1[,2]
  c2 = c2[p]

  output_sort <- cbind(output_sort, c2)
}

rownames(output_sort) = sort(i_file1[,1])
colnames(output_sort) = all_genes1

output_order = output_sort[,order(colnames(output_sort))]

write.csv(output_order, file = "2023-5-17-UminP-germline-somaticDriver-association-pvalue_order.csv")

#################################################################################################
sum(output_order<0.05)
# [1] 1729
# 1729/23400 = 0.07388889

### aSPU result 
# [1] 1728
# 1728/23400 = 0.07384615

