## UminP multiple testing correction: FDR

library(data.table)
library(varhandle)
library(gplots)

setwd("D:/Work/PhDThesis/manuscript/germsom/Revision/Data/UminP")

########### read p values from aSPU assciation test results 2023-5-16 #############
pval <- read.csv("2023-5-17-UminP-germline-somaticDriver-association-pvalue_order.csv")
rownames(pval) <- pval$X
pval <- pval[,-1]        ## each row is somatic mutation gene, each column is germline gene (154 by 148)  


################################# FDR correction ###################################################
# p.adjust(p, method = p.adjust.methods, n = length(p))
# p.adjust.methods: c("holm", "hochberg", "hommel", "bonferroni", "BH", "BY","fdr", "none")

fdr_matrix <- matrix(p.adjust(as.vector(as.matrix(pval)), method='fdr'),ncol=150)
sum(fdr_matrix<0.2) # [1] 159   aSPU # [1] 210
sum(fdr_matrix<0.1) # [1] 0

fdr_matrix_df <- as.data.frame(fdr_matrix)
rownames(fdr_matrix_df) <- rownames(pval)
colnames(fdr_matrix_df) <- colnames(pval)

write.csv(fdr_matrix_df, file = "2023-5-17-UminP-germline-somaticDriver-association-fdr.csv")


##################################### Heatmap #######################################################
## -log10(pvalues) --- color
## box --- fdr < 0.2
## only inclued genes whose frequency is greater or equal to 1% (57genes)

## select genes 
gene_freq001 <- read.csv("2019-5-12-driver-gene-freq001.csv")
gene_freq001 <- gene_freq001[,-1]
# gene_freq001 <- unfactor(gene_freq001)


pval_freq001 <- pval[which(rownames(pval) %in% gene_freq001), which(colnames(pval) %in% gene_freq001)]  
pval_freq001_mtx <- as.matrix(pval_freq001)
pval_freq001_mtx1 <- -log10(pval_freq001_mtx)

lwid = c(1.2,2)
lhei = c(1.5,12,4)
lmat = rbind(c(0,3),c(2,1),c(0,4))

## heatmap p values for genes whose frequency greater or equal to 0.01
pdf(file = "2023-5-17-UminP-aSPU-germline-somatic-association-freq001_genes-pvalues.pdf", 20, 17)
heatmap.2(pval_freq001_mtx1,col=bluered(100),margin=c(8, 12),cexCol = 1.6,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=1.8,lmat = lmat, lwid = lwid, lhei = lhei, keysize=1, key.par = list(cex=1.2))  ##  Colv: do not reorder column
dev.off()


## heatmap p values for all genes
pval_mtx <- as.matrix(pval)
pval_mtx1 <- -log10(pval_mtx)

pdf(file = "2023-5-17-UminP-germline-somatic-association-all_genes-pvalues.pdf", 20, 17)
heatmap.2(pval_mtx1,col=bluered(100),margin=c(8, 12),cexCol = 0.5,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=0.5)  ##  Colv: do not reorder column
dev.off()


## heatmal fdr for genes whose frequency greater or equal to 0.01
fdr_matrix_df_freq001 <- fdr_matrix_df[which(rownames(fdr_matrix_df) %in% gene_freq001), which(colnames(fdr_matrix_df) %in% gene_freq001)]

fdr_matrix_df_freq001_mtx <- as.matrix(fdr_matrix_df_freq001)
fdr_matrix_df_freq001_mtx1 <- -log10(fdr_matrix_df_freq001_mtx)

pdf(file = "2023-5-17-UminP-germline-somatic-association-freq001_genes-fdr.pdf", 20, 17)
heatmap.2(fdr_matrix_df_freq001_mtx1,col=bluered(100),margin=c(8, 12),cexCol = 1.6,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=1.8,lmat = lmat, lwid = lwid, lhei = lhei, keysize=1, key.par = list(cex=1.2))  ##  Colv: do not reorder column
dev.off()


## heatmal fdr for all genes 
fdr_matrix_df_mtx <- as.matrix(fdr_matrix_df)
fdr_matrix_df_mtx1 <- -log10(fdr_matrix_df_mtx)

pdf(file = "2023-5-17-UminP-germline-somatic-association-all_genes-fdr.pdf", 20, 17)
heatmap.2(fdr_matrix_df_mtx1,col=bluered(100),margin=c(8, 12),cexCol = 0.5,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=0.5)  ##  Colv: do not reorder column
dev.off()

