## test association between germline SNPs and somatic mutation driver genes 
## UminP

library(data.table)
library(varhandle)
library("aSPU")

setwd("D:/Work/Wei/Data/Association/matrix012v2")

################################################### X data #########################################################
## read sample id 
tcga_sampleid <- fread("tcga.clean.sampleid", header = FALSE )
icgc_sampleid <- fread("icgc.clean.sampleid", header = FALSE)

## read annotated genes from oncotator 
tcga_oncotator <- fread("oncotator.tcga.useful.uniq.v2", fill = TRUE , header = TRUE)
icgc_oncotator <- fread("oncotator.icgc.useful.uniq.v2",fill = TRUE , header = TRUE)

#############################################################
## read driver gene list 
setwd("D:/Work/Wei/Data/Association")
# driver_gene <- read.csv("2019-4-16-dirver-gene-toUse.csv")
driver_gene <- read.csv("2019-5-3-driver-gene-toUse.csv")
driver_gene1 <- driver_gene[,-1]
driver_gene2 <- unfactor(driver_gene1)
#############################################################

tcga_oncotator_driver <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% driver_gene2),]
tcga_genes = unique(tcga_oncotator_driver$Hugo_Symbol)
# [1] 150

icgc_oncotator_driver <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% driver_gene2),]
icgc_genes = unique(icgc_oncotator_driver$Hugo_Symbol)
# [1] 150

all.equal(tcga_genes,icgc_genes) # same

all_genes = tcga_genes # same

#################

setwd("D:/Work/PhDThesis/data/2019-5-8aSPUpvalues")

for (i in 1:40){
  
  gene = all_genes[i]
  
  ################################ Association test ############################################################
  rdata_aSPU = paste("2019-5-8-germline",gene,"-somaticDriver-association-pvalue.rdata",sep="")
  
  load(rdata_aSPU)
  
  #### UminP ############
  date()
  pvuminp <- c()
  for (j in 1:length(driver)){
    out <- aSPU(somatic_driver_order[,j], merged_data_i, cov = NULL, resample = "boot",model = "binomial", pow = Inf, n.perm = 1000)
    pvuminp[j] <- out$pvs[length(out$pvs)]
  }
  date()

  #sum(pvaspu<0.05)
  #sort(pvaspu)
  
  output <- data.frame(driver,pvuminp)
  output1 <- output[order(output$pvuminp),]
  
  csvname = paste("2023-5-17-UminP-germline",gene,"-somaticDriver-association-pvalue.csv",sep="")
  write.csv(output1, file = csvname)
  
  rdataname = paste("2023-5-17-UminP-germline",gene,"-somaticDriver-association-pvalue.rdata",sep="")
  save(merged_data_i, somatic_driver, somatic_driver_order, driver, output1, file = rdataname)
}
