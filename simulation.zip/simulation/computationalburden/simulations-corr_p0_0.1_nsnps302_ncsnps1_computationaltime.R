# setwd("D:/Work/Wei")
library("aSPU")

nsnps = c(15, 13, 4, 17, 20, 16, 20, 15, 13, 4, 15, 15, 20, 19, 16, 20, 19, 12, 14, 15)

nsim = 1000
# nsim = 1

nsubject = 500
ncgene = 1
rhos = c(0, 0.8)
p0 = 0.1

ngene = 20
ncsnps = c(rep(1,ncgene),rep(0, ngene-ncgene))

g1 = c(1:8)
g2 = c(1,2,4,8)

date()
# [1] "Sun May 21 16:24:51 2023"

timeaSPU <- c()
timeaSPUpath <- c()
timeSSU <- c()
timeUminP <- c()
timeHYST <- c()
timeGatesSimes <- c()
pvaspu <- c()
pvaspu1n <- c()
pvaspupath <- c()
pvaspupathn <- c()
pvhyst <- c()
pvgs <- c()
pvssu <- c()
pvuminp <- c()
  for (j in 1:nsim){
    dat1 <- simPathAR1Snp(nGenes = ngene, nGenes1 = ncgene, nSNPs = nsnps, ncSNPs = ncsnps,
                           nSNPlim = c(1, ngene), nSNP0 = 1, LOR = 0.2, n = nsubject,
                           MAFlim = c(0.05, 0.4), rholim = rhos, p0 = p0, noncausal = FALSE)
    
    ##### aSPU #####
    time1 = Sys.time()
    out1 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g1, n.perm = 500)
    time2 = Sys.time()
    timeaSPU[j] = time2 - time1
    pvaspu[j] <- out1$pvs[length(out1$pvs)]
    
    ##### aSPUpath #####
    time3 = Sys.time()
    out2 <- aSPUpath(dat1$Y, dat1$X, snp.info = dat1$snp.info,gene.info = dat1$gene.info,model = "binomial", pow=g1, pow2=g2, n.perm=500)
    time4 = Sys.time()
    timeaSPUpath[j] = time4 - time3
    pvaspupath[j] <- out2[length(out2)]
    
    #### SSU ##############
    time5 = Sys.time()
    out3 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = 2, n.perm = 500)
    time6 = Sys.time()
    timeSSU[j] = time6 - time5
    pvssu[j] <- out3$pvs[length(out3$pvs)]
    
    #### UminP ############
    time7 = Sys.time()
    out4 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = Inf, n.perm = 500)
    time8 = Sys.time()
    timeUminP[j] = time8 - time7
    pvuminp[j] <- out4$pvs[length(out4$pvs)]
    
    #### HYST ###############
    time9 = Sys.time()
    logitp <- getlogitp(dat1$Y, dat1$X)
    
    ## get correlation of SNPs using controls
    ldmat <- cor(dat1$X[ dat1$Y == 0, ])
    out5 <- Hyst(pvec = logitp, ldmatrix = ldmat, snp.info = dat1$snp.info,gene.info = dat1$gene.info)
    time10 = Sys.time()
    timeHYST[j] = time10 - time9
    pvhyst[j] <- out5[length(out5)]

    #### GatesSimes #########
    time11 = Sys.time()
    logitp <- getlogitp(dat1$Y, dat1$X)
    
    ## get correlation of SNPs using controls
    ldmat <- cor(dat1$X[ dat1$Y == 0, ])
    out6 <- GatesSimes(pvec = logitp, ldmatrix = ldmat, snp.info = dat1$snp.info, gene.info = dat1$gene.info)
    time12 = Sys.time()
    timeGatesSimes[j] = time12 - time11
    pvgs[j] <- out6[length(out6)]
  }
  
mean(timeaSPU)
# [1] 0.8902343
sd(timeaSPU)
# [1] 0.02648555
mean(timeaSPUpath)
# [1] 1.135747
sd(timeaSPUpath)
# [1] 0.03768895
mean(timeSSU)
# [1] 0.8086824
sd(timeSSU)
# [1] 0.02968364
mean(timeUminP)
# [1] 0.7939939
sd(timeUminP)
# [1] 0.03026169
mean(timeHYST)
# [1] 1.071845
sd(timeHYST)
# [1] 0.01657334
mean(timeGatesSimes)
# [1] 1.068505
sd(timeGatesSimes)
# [1] 0.01223718

date()
# [1] "Sun May 21 18:31:51 2023"
