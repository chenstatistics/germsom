setwd("D:/Work/Wei")
library("aSPU")
# source("aSPUn.r")
# source("aSPUbootn.r")
# source("aSPUpathn.r")
source("simPathAR1Snp2.r")
####################################################################################################################################
# ### simPathAR1Snp Usage
# simPathAR1Snp2(nGenes = 10, nGenes1 = 5, nSNPs = NULL, ncSNPs = NULL,
#               nSNPlim = c(1, 20), nSNP0 = 1:3, LOR = 0.3, n = 100,
#               MAFlim = c(0.05, 0.4), rholim = c(0, 0), p0 = 0.80, noncausal = FALSE)
# 
# ### aSPU usage 
# aSPU(Y, X, cov = NULL, resample = c("perm", "boot", "sim"),model = c("gaussian", "binomial"), pow = c(1:8, Inf), n.perm = 1000)

######################################## 1000 replicates ###########################################################################
a <- c(0,seq(from = 0.2, to = 0.6, by = 0.1))
pwaspu <- c()
pwaspu1n <- c()
pwaspupath <- c()
pwaspupathn <- c()
pwhyst <- c()
pwgs <- c()
pwssu <- c()
pwuminp <- c()

#nsnps = sample(1:20,20, replace = TRUE)
#load("2018-7-25-nsnps.rdata") # 15 13  4 17 20 16 20 15 13  4 15 15 20 19 16 20 19 12 14 15
nsnps = c(15, 13, 4, 17, 20, 16, 20, 15, 13, 4, 15, 15, 20, 19, 16, 20, 19, 12, 14, 15)

nsim = 1000

nsubject = 500
ncgene = 10
rhos = c(0, 0.8)
p0 = 0.1

ngene = 20
ncsnps = c(rep(1,ncgene),rep(0, ngene-ncgene))

#g = c(1:16,Inf,1/4,1/3,1/2,seq(100,800,200))
g1 = c(1:8)
g2 = c(1, 2, 3, 5, 7, Inf)

for (i in 1:length(a)){
  pvaspu <- c()
  pvaspu1n <- c()
  pvaspupath <- c()
  pvaspupathn <- c()
  pvhyst <- c()
  pvgs <- c()
  pvssu <- c()
  pvuminp <- c()
  
  for (j in 1:nsim){
    if (j %% 100 == 0) {message (i,': ', j,'   ',date())}
    # dat1<-simPathAR1Snp(nGenes=20, nGenes1=1, nSNPlim=c(1, 20),nSNP0=1, LOR=a[i], rholim=c(0,0),n=100, MAFlim=c(0.05, 0.4), p0=0.05,noncausal = FALSE )
    dat1 <- simPathAR1Snp2(nGenes = ngene, nGenes1 = ncgene, nSNPs = nsnps, ncSNPs = ncsnps,
                           nSNPlim = c(1, ngene), nSNP0 = 1, LOR = a[i], n = nsubject,
                           MAFlim = c(0.05, 0.4), rholim = rhos, p0 = p0, noncausal = FALSE)
    
    ##### aSPU #####
    out1 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g1, n.perm = 500)
    pvaspu[j] <- out1$pvs[length(out1$pvs)]
    
    out1n <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g2, n.perm = 500)
    pvaspu1n[j] <- out1n$pvs[length(out1n$pvs)]
    
    out2pv <- aSPUpath(dat1$Y, dat1$X, snp.info = dat1$snp.info,gene.info = dat1$gene.info,model = "binomial", pow=g1, pow2=c(1,2,4,8), n.perm=500)
    pvaspupath[j] <- out2pv[length(out2pv)]

    out2pvn <- aSPUpath(dat1$Y, dat1$X, snp.info = dat1$snp.info,gene.info = dat1$gene.info,model = "binomial", pow=g2, pow2=c(1,2,4,8), n.perm=500)
    pvaspupathn[j] <- out2pvn[length(out2pvn)]
    
    #### HYST ###############
    logitp <- getlogitp(dat1$Y, dat1$X)
    ## get correlation of SNPs using controls
    ldmat <- cor(dat1$X[ dat1$Y == 0, ])
    #ldmat = cor(dat1$X)
    out3pv <- Hyst(pvec = logitp, ldmatrix = ldmat, snp.info = dat1$snp.info,gene.info = dat1$gene.info)
    pvhyst[j] <- out3pv[length(out3pv)]
    
    #### GatesSimes #########
    out4pv <- GatesSimes(pvec = logitp, ldmatrix = ldmat, snp.info = dat1$snp.info, gene.info = dat1$gene.info)
    pvgs[j] <- out4pv[length(out4pv)]
    
    #### SSU ##############
    out5 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = 2, n.perm = 500)
    pvssu[j] <- out5$pvs[length(out5$pvs)]
    
    #### UminP ############
    out6 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = Inf, n.perm = 500)
    pvuminp[j] <- out6$pvs[length(out6$pvs)]
  }
  
  pwaspu[i] <- sum(pvaspu < 0.05)/length(pvaspu)
  pwaspu1n[i] <- sum(pvaspu1n < 0.05)/length(pvaspu1n)
  pwaspupath[i] <- sum(pvaspupath < 0.05)/length(pvaspupath)
  pwaspupathn[i] <- sum(pvaspupathn < 0.05)/length(pvaspupathn)
  pwhyst[i] <- sum(pvhyst < 0.05)/length(pvhyst)
  pwgs[i] <- sum(pvgs < 0.05)/length(pvgs)
  pwssu[i] <- sum(pvssu < 0.05)/length(pvssu)
  pwuminp[i] <- sum(pvuminp < 0.05)/length(pvuminp)
}

save(pwaspu,pwaspu1n,pwaspupath,pwaspupathn,pwhyst,pwgs,pwssu,pwuminp,file="2019-5-30-simulations-corr_p0_0.1_nsnps302_ncsnps10.rdata")

matplot(a[2:6],cbind(pwaspu[2:6],pwaspupath[2:6],pwhyst[2:6],pwgs[2:6],pwssu[2:6],pwuminp[2:6]),type="b",pch=1:6, col=1:6, ylim=c(0,1), xlab = "log OR", ylab = "Power" ,cex=1.8, cex.axis=1.8,cex.lab=1.8,cex.main=1.8)
legend("topleft", inset=0.01, legend=c("aSPU","aSPUpath","HYST","GatesSimes","SSU","UminP"), col=c(1:6),pch=1:6,bg= ("white"), horiz=F,cex=1.5)

matplot(a[2:6],cbind(pwaspu[2:6],pwaspu1n[2:6],pwaspupath[2:6],pwaspupathn[2:6]),type="b",pch=1:4, col=1:4, ylim=c(0,1), xlab = "log OR", ylab = "Power" ,cex=1.8, cex.axis=1.8,cex.lab=1.8,cex.main=1.8)
legend("topleft", inset=0.01, legend=c("aSPU","aSPU-PP","aSPUpath","aSPUpath-PP"), col=c(1:4),pch=1:4,bg= ("white"), horiz=F,cex=1.5)

message(pwaspu[1],' ',pwaspupath[1],' ',pwhyst[1],' ',pwgs[1],' ',pwssu[1],' ',pwuminp[1])
message(pwaspu[1],' ',pwaspu1n[1],' ',pwaspupath[1],' ',pwaspupathn[1])

