setwd("D:/Work/Wei")
## 2023-5-25 sample size vary
## 2023-6-30 update

library("aSPU")
source("simPathAR1Snp1.r")

nsnps = c(15, 13, 4, 17, 20, 16, 20, 15, 13, 4, 15, 15, 20, 19, 16, 20, 19, 12, 14, 15)

nsim = 1000
# nsim = 2

# nsubject = c(100,500,1000,2000,4000)
nsubject = c(100,200,300,400,500,1000,2000)
# nsubject = c(100,500)
ncgene = 10
rhos = c(0, 0.8)
p0 = 0.1

ngene = 20
ncsnps = c(rep(1,ncgene),rep(0, ngene-ncgene))

#g = c(1:16,Inf,1/4,1/3,1/2,seq(100,800,200))
g1 = c(1:8)
g2 = c(1,2,4,8)

pwaspu <- c()
pwaspupath <- c()
pwhyst <- c()
pwgs <- c()
pwssu <- c()
pwuminp <- c()
for (i in 1:length(nsubject)){
  pvaspu <- c()
  pvaspupath <- c()
  pvhyst <- c()
  pvgs <- c()
  pvssu <- c()
  pvuminp <- c()
  
  for (j in 1:nsim){
    if (j %% 100 == 0) {message (i,': ', j,'   ',date())}
    # dat1<-simPathAR1Snp(nGenes=20, nGenes1=1, nSNPlim=c(1, 20),nSNP0=1, LOR=a[i], rholim=c(0,0),n=100, MAFlim=c(0.05, 0.4), p0=0.05,noncausal = FALSE )
    dat1 <- simPathAR1Snp(nGenes = ngene, nGenes1 = ncgene, nSNPs = nsnps, ncSNPs = ncsnps,
                           nSNPlim = c(1, ngene), nSNP0 = 1, LOR = 0.4, n = nsubject[i],
                           MAFlim = c(0.05, 0.4), rholim = rhos, p0 = p0, noncausal = FALSE)
    
    ##### aSPU #####
    out1 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g1, n.perm = 500)
    pvaspu[j] <- out1$pvs[length(out1$pvs)]
    
    out2pv <- aSPUpath(dat1$Y, dat1$X, snp.info = dat1$snp.info,gene.info = dat1$gene.info,model = "binomial", pow=g1, pow2=g2, n.perm=500)
    pvaspupath[j] <- out2pv[length(out2pv)]
    
    #### HYST ###############
    logitp <- getlogitp(dat1$Y, dat1$X)
    ## get correlation of SNPs using controls
    ldmat <- cor(dat1$X[ dat1$Y == 0, ])
    #ldmat = cor(dat1$X)
    out3pv <- Hyst(pvec = logitp, ldmatrix = ldmat, snp.info = dat1$snp.info,gene.info = dat1$gene.info)
    pvhyst[j] <- out3pv[length(out3pv)]
    
    #### GatesSimes #########
    out4pv <- GatesSimes(pvec = logitp, ldmatrix = ldmat, snp.info = dat1$snp.info, gene.info = dat1$gene.info)
    pvgs[j] <- out4pv[length(out4pv)]
    
    #### SSU ##############
    out5 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = 2, n.perm = 500)
    pvssu[j] <- out5$pvs[length(out5$pvs)]
    
    #### UminP ############
    out6 <- aSPU(dat1$Y, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = Inf, n.perm = 500)
    pvuminp[j] <- out6$pvs[length(out6$pvs)]
  }
  
  pwaspu[i] <- sum(pvaspu < 0.05)/length(pvaspu)
  pwaspupath[i] <- sum(pvaspupath < 0.05)/length(pvaspupath)
  pwhyst[i] <- sum(pvhyst < 0.05)/length(pvhyst)
  pwgs[i] <- sum(pvgs < 0.05)/length(pvgs)
  pwssu[i] <- sum(pvssu < 0.05)/length(pvssu)
  pwuminp[i] <- sum(pvuminp < 0.05)/length(pvuminp)
}

save(pwaspu,pwaspupath,pwhyst,pwgs,pwssu,pwuminp,file="2023-6-30-simulations-corr_p0_0.1_nsnps302_ncsnps10_samplesize.rdata")

matplot(nsubject[1:7],cbind(pwaspu[1:7],pwaspupath[1:7],pwhyst[1:7],pwgs[1:7],pwssu[1:7],pwuminp[1:7]),type="b",
        pch=1:6, col=1:6, ylim=c(0,1), xlab = "sample size", ylab = "Power" ,cex=1.8, cex.axis=1.8,cex.lab=1.8,cex.main=1.8)
legend("bottomright", inset=0.01, legend=c("aSPU","aSPUpath","HYST","GatesSimes","SSU","UminP"), col=c(1:6),
       pch=1:6,bg= ("white"), horiz=F,cex=1.5)

# message(pwaspu[1],' ',pwaspupath[1],' ',pwhyst[1],' ',pwgs[1],' ',pwssu[1],' ',pwuminp[1])

matplot(nsubject[1:6],cbind(pwaspu[1:6],pwaspupath[1:6],pwhyst[1:6],pwgs[1:6],pwssu[1:6],pwuminp[1:6]),type="b",
        pch=1:6, col=1:6, ylim=c(0,1), xlab = "sample size", ylab = "Power" ,cex=1.8, cex.axis=1.8,cex.lab=1.8,cex.main=1.8)
legend("bottomright", inset=0.01, legend=c("aSPU","aSPUpath","HYST","GatesSimes","SSU","UminP"), col=c(1:6),
       pch=1:6,bg= ("white"), horiz=F,cex=1.5)
